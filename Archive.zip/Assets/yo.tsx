<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="yo" tilewidth="185" tileheight="504" tilecount="1" columns="1">
 <image source="yo.png" width="185" height="504"/>
</tileset>
